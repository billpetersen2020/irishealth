MEDICARE:

SELECT p.Id,'' as addressid
	FROM CVS_CDR_MasterRoster.Record AS r
	JOIN (SELECT Id, Member, MAX(StagedPlanEffectiveDate) As MostRecentDate, StagedPlanTerminationDate, LOB 
		FROM CVS_CDR_MasterRoster.Plan GROUP BY Member) AS p ON p.Member = r.Id 
	WHERE p.LOB='MEDICARE'
	AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(Current_Date)
	
MEDICAID:

SELECT p.Id,'' as addressid
              FROM CVS_CDR_Medicaid_MasterRoster.Record AS r
              JOIN CVS_CDR_Medicaid_MasterRoster.Plan As p On r.ID = p.Member
Where UPPER(p.LOB) = 'MEDICAID' and TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(Current_Date)