PCC_Medicare:

-- PROD SQL before 15 State CHANGE
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON p.Member = a.Member
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL')

-- PROD SQL
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON p.Member = a.Member
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')

-- ORIGINAL QUERY
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')
 --> Record Count: 1,101,042
 
 select count(UniqueMember), UniqueMember from
(
SELECT {fn CONCAT(IMICVSSSK, HRPIDCVSSSK)} AS UniqueMember
FROM PCC_Data_PCC.MasterRoster
)
group by UniqueMember 
having count(UniqueMember)>1

-- NEW QUERY
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)
 --> Record Count: 1,099,662
--MemberStatus,FacilityCode,FirstName,MiddleName,LastName,AddressLine1,AddressLine2,City,State,Zip,
--DateOfBirth,Gender,Homephone,Workphone,Cellphone,Vendor1,REGION,InsuranceGroup,ProgramName,URNMBIID,IMICVSSSK,HRPIDCVSSSK

SELECT 'ADD' As Status,{fn CONCAT('Aetna-MC-', a.State)} as FacilityCode,
		p.Member->FirstName,p.Member->MiddleInitial as MiddleName, p.Member->LastName,
		a.Line1 as AddressLine1,a.Line2 as AddressLine2,a.City,a.State,a.Zip,
		p.Member->DateOfBirth,p.Member->Gender,p.Member->Phone as Homephone,
		p.Member->Phone as Workphone,p.Member->Phone as Cellphone,'Y' as Vendor1,
		'AI' as REGION,p.LOB as InsuranceGroup,p.Identifier as ProgramName,
		p.Member->CarrierMemberID as URNMBIID,p.Member->SSK as IMICVSSSK, p.UniqueMemberID as HRPIDCVSSSK
FROM CVS_CDR_MasterRoster.Plan As p
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB = 'MEDICARE'


SELECT DISTINCT p.Member->Status,{fn CONCAT('Aetna-MC-', a.State)} as State,p.Member->FirstName,p.Member->MiddleInitial,p.Member->LastName,a.Line1,a.Line2,a.City,a.State,a.Zip,p.Member->DateOfBirth,p.Member->Gender,p.Member->Phone,p.Member->Phone,p.Member->Phone,'Y','AI',p.LOB,p.Identifier,p.Member->CarrierMemberID,p.Member->SSK, p.UniqueMemberID
FROM CVS_CDR_MasterRoster.Record As r
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB = 'MEDICARE'

SELECT DISTINCT r.Status,{fn CONCAT('Aetna-MC-', a.State)} as State,r.FirstName,r.MiddleInitial,r.LastName,a.Line1,a.Line2,a.City,a.State,a.Zip,r.DateOfBirth,r.Gender,r.Phone,r.Phone,r.Phone,'Y','AI',p.LOB,p.Identifier,r.CarrierMemberID,r.SSK, p.UniqueMemberID
FROM CVS_CDR_MasterRoster.Record As r
JOIN CVS_CDR_MasterRoster.Plan AS p ON (r.ID = p.Member) and 
     CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB = 'MEDICARE'


SELECT DISTINCT r.Status,{fn CONCAT('Aetna-MC-', a.State)} as State,r.FirstName,r.MiddleInitial,r.LastName,a.Line1,a.Line2,a.City,a.State,a.Zip,r.DateOfBirth,r.Gender,r.Phone,r.Phone,r.Phone,'Y','AI',p.LOB,p.Identifier,r.CarrierMemberID,r.SSK, p.UniqueMemberID
FROM CVS_CDR_MasterRoster.Record As r
JOIN CVS_CDR_MasterRoster.Plan AS p ON (r.ID = p.Member) and 
     CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB = 'MEDICARE'



-- 1,380 fewer roster records in the new query

-- 1,108,516 - Feb 1
-- 1,101,042

SELECT DISTINCT "Plan".Member->Status,"Address".State,"Plan".Member->FirstName,"Plan".Member->MiddleInitial,
"Plan".Member->LastName,"Address".Line1,"Address".Line2,"Address".City,"Address".State,
"Address".Zip,"Address".Member->StagedDateOfBirth,"Address".Member->Gender,"Plan".Member->Phone,
"Plan".Member->Phone,"Plan".Member->Phone,"Plan".InsuranceSubRelationship,"Plan".Identifier,
"Plan".LOB,"Plan".Identifier,"Address".Member->CarrierMemberID,"Address".Member->SSK
join
FROM CVS_CDR_MasterRoster.Record "Record",CVS_CDR_MasterRoster.Plan "Plan",CVS_CDR_MasterRoster.Address "Address"
WHERE "Plan".LOB = 'MEDICARE'
Dale H. Original Query for PCC Medicare Member Roster:
1,101,042

Dale H. New Query for PCC Medicare Member Roster (Remove Duplicates):
1,099,662



PAHSX-Medicare:

SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State ='PA'
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


HEDIS_Healthx_ADT_Enrollement:

SELECT 	distinct p.Id
	FROM CVS_CDR_MasterRoster.Plan AS p
		JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
	WHERE TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > 
 TO_DATE(+$ZTIMESTAMP,'YYYYMMDD')
		AND a.State = 'NY'
		AND p.LOB='Medicare'
		AND p.InsuranceSubRelationship='S'
		AND p.GroupName <> 'Individual'
	group by p.member
	having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)
	
	
HEDIS_GHH_CCD:

SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Record AS mr ON p.Member = mr.ID
JOIN Temp_GHH_CCD_Subscription.Members AS ghhSub ON mr.SSK = ghhSub.INDIVIDUAL_ID
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='MEDICARE' AND a.State = 'TX'
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


HEDIS_GHH_ADT:

SELECT 	distinct p.Id
	FROM CVS_CDR_MasterRoster.Plan AS p
		JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
	WHERE TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > 
 TO_DATE(+$ZTIMESTAMP,'YYYYMMDD')
		AND a.State = 'TX'
		AND p.LOB='Medicare'
		AND p.InsuranceSubRelationship='S'
		AND p.GroupName <> 'Individual'
	group by p.member
	having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)	
		
		
HEDIS_Connie_ADT:

SELECT 	distinct p.Id
	FROM CVS_CDR_MasterRoster.Plan AS p
		JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
	WHERE TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > 
 TO_DATE(+$ZTIMESTAMP,'YYYYMMDD')
		AND a.State = 'CT'
		AND p.LOB='Medicare'
		AND p.InsuranceSubRelationship='S'
		AND p.GroupName <> 'Individual'
	group by p.member
	having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)
		
		
EPP Medicare Termed 1123:

SELECT p.id FROM  CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='MEDICARE'
AND StagedPlanTerminationDate >'2023-01-01'
AND (p.SubSegment NOT in ('AES', 'AGB', 'BHI', 'TRO')) 
AND (a.State NOT in ('ZZ', 'AE'))
AND p.BrandedPayerName is NOT NULL
AND p.BrandedPlanName is NOT NULL 
AND p.ReferenceFinancialClass is NOT NULL
AND p.ReferencePayer is NOT NULL
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


EPP Medicare:

SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(DATEADD('month',-2,+$ZTIMESTAMP),'YYYY-MM-DD')
AND (p.SubSegment NOT in ('AES', 'AGB', 'BHI', 'TRO')) 
AND (a.State NOT in ('ZZ', 'AE'))
AND p.BrandedPayerName is NOT NULL
AND p.BrandedPlanName is NOT NULL 
AND p.ReferenceFinancialClass is NOT NULL
AND p.ReferencePayer is NOT NULL
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


EPP Commercial Term 1_1_23:

SELECT p.id FROM  CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='COMMERCIAL'
AND StagedPlanTerminationDate >'2023-01-01'
AND (p.SubSegment NOT in ('AES', 'AGB', 'BHI', 'TRO')) 
AND (a.State NOT in ('ZZ', 'AE'))
AND p.BrandedPayerName is NOT NULL
AND p.BrandedPlanName is NOT NULL 
AND p.ReferenceFinancialClass is NOT NULL
AND p.ReferencePayer is NOT NULL
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


EPP Commercial Roster:

SELECT p.id FROM  CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='COMMERCIAL'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(DATEADD('month',-2,+$ZTIMESTAMP),'YYYY-MM-DD')
AND (p.SubSegment NOT in ('AES', 'AGB', 'BHI', 'TRO')) 
AND (a.State NOT in ('ZZ', 'AE'))
AND p.BrandedPayerName is NOT NULL
AND p.BrandedPlanName is NOT NULL 
AND p.ReferenceFinancialClass is NOT NULL
AND p.ReferencePayer is NOT NULL
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)


EPP Cleanup:

SELECT Top 10 (p.Id)
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member AND p.StagedPlanEffectiveDate = a.EffectiveDate)
WHERE p.LOB='COMMERCIAL'
AND (p.SubSegment NOT in ('AES', 'AGB', 'BHI', 'TRO')) 
AND (a.State NOT in ('ZZ', 'AE'))
AND p.BrandedPayerName is NOT NULL
AND p.BrandedPlanName is NOT NULL 
AND p.ReferenceFinancialClass is NOT NULL
AND p.ReferencePayer is NOT NULL
group by p.member
having p.stagedplaneffectivedate = max(p.stagedplaneffectivedate)
	
	
