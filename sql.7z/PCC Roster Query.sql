/*
Dale H - Original Query
*/
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON (p.Member = a.Member)
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')index="edp" project_id="edp-prod-eds-cdr-cis" container_name=iriscluster jsonPayload.CIS_DATATYPE="ORU" jsonPayload.CIS_SOURCE="*KYHIE*" "jsonPayload.STEP_NAME"=Ingestion

-- PCC Roster Generaton (Record Count Per State)
/*
FL	356,368	
IL	327,620	
AK	1,100	
HI	1,594	
KY	33,946	
MA	64,423	
MO	150,615	
MT	1,512	
NE	17,553	
NH	14,838	
NM	2,332	
NV	44,828	
OR	15,789	
RI	7,509	
UT	18,714	
WV	49,774	
Total:	1,108,515 Roster Size
*/ 

-- TASK TIME TO COMPLETE:
-- >> 5 States: 'FL','IL','AK','HI'
--		==>  8 Minutes | Record Count:  720,628
-- >> 16 States: 'FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV'
--		==> 15 Minutes | Record Count: 1,108,515

-- Working Copy
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON p.Member = a.Member
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','KY','MA','MO','MT','NE','NH','NM','NV','OR','RI','UT','WV')

-- Original
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON p.Member = a.Member
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL')

--SUB QUERY - GET COUNT
SELECT count(*) from 
(
SELECT p.Id
FROM CVS_CDR_MasterRoster.Plan As p 
JOIN CVS_CDR_MasterRoster.Address AS a ON p.Member = a.Member
WHERE p.LOB='MEDICARE'
AND TO_DATE(p.StagedPlanTerminationDate,'YYYYMMDD') > TO_DATE(+$ZTIMESTAMP,'YYYY-MM-DD')
AND a.State IN ('FL','IL','AK','HI','IL')  
) as sub

-- MEDICARE ROSTER SIZE
/*
FL	356368
IL	327620
AK	1100
HI	1594
KY	33946
MA	64423
MO	150615
MT	1512
NE	17553
NH	14838
NM	2332
NV	44828
OR	15789
RI	7509
UT	18714
WV	49774
==========
TOTAL PCC ROSTER SIZE:  1,108,515
*/